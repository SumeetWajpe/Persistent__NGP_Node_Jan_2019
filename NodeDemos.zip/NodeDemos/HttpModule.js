var http = require('http');
var fs = require('fs');
var port = 5000; 

var server = http.createServer(function(req,res){
    fs.readFile(__dirname + "/Index.html",function(err,data){
                if(err){
                    console.log(err)
                }else{
                    //console.log(req.method);
                    res.writeHead(200,{'Content-Type':'text/html'});
                    return res.end(data)
                }
    });// eof readFile       
});// eof createServer
server.listen(port,'127.0.0.1',()=>{
    console.log(`Server running at localhost:${port}`);
});