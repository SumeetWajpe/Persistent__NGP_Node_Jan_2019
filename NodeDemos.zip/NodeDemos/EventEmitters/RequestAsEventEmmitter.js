var request = require('request');
var fs = require('fs');
var src = request('http://www.google.com'); // Returns An object of EventEmmitter

var response = "";

src.on('data',function(chunkOfData){
     //   console.log('\n\n>>>>>>>>>>>>>>>>>>>>>> DATA >>>>>>>>>>>>>>>>>>>' + chunkOfData.toString())
        response += chunkOfData;
});


src.on('end',function(){
    //console.log('>>>>>> DONE >>>>>>');
    fs.writeFile('GoogleResponse.html',response);
});