var fs = require('fs');
var readableStream = fs.createReadStream('Input.txt');
var writeableStream = fs.createWriteStream("Output.txt");

var allData = "";
readableStream.setEncoding("UTF-8");
// readableStream.on('data',function(chunk){
//     allData += chunk;
// });

// readableStream.on('end',function(){
//     writeableStream.write(allData);
//     writeableStream.end();
// });

readableStream.pipe(writeableStream);
