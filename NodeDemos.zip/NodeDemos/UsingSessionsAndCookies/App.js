

var express = require('express');
var session = require('express-session');
var ckparser = require('cookie-parser');


var app = express();

app.use(ckparser());
app.use(session({
    secret : 'anyStringofText',
    saveUninitialized: true,
    resave:true
}));
app.use('/', function (req, res) { 

    res.send('Our first Cookie and Session Mgmnt !');

    console.log(req.cookies);
    console.log("================");
    console.log(req.session);

    var sess = req.session;// session state !

    sess.Value = "ActualValue"; // array JSON /Javascript object
});

app.listen(9090);
console.log('Running..')