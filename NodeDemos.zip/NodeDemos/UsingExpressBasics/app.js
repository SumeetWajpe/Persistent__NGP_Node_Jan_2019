var express = require('express');
var app = express();

app.get('/',(req,res)=>{
        var skills = [
            {name:'React'},
        {name:'Angular'},
        {name:'Node'}];

        //res.send("<h1> Welcome to Express ! </h1>");
        res.sendFile('Index.html',{root:__dirname});
        //res.json(skills);
});

app.listen(5000,()=>{
    console.log('Server running at port 5000 !')
})