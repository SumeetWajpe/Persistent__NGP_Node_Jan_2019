var express = require('express');
var bodyParser = require('body-parser');

var app = express();
var router = express.Router();
router.route('/products/:name').get(function(req,res){
    var products = [
        {name:'Mobile',price:20000},
        {name:'TV',price:30000},
        {name:'Laptop',price:40000}
    ];
        var pName = req.params.name;
        var theProduct = products.find(p=>p.name == pName);
        if(theProduct){
                res.json(theProduct);
        }else{
            res.json(products);
        }
}); 
app.use('/',router);// Express now knows how to match the routes !
app.use(bodyParser.json())
app.get('/',function(req,res){
    res.sendFile('Index.html',{root:__dirname});
});

app.post('/login',function(req,res){  
    console.log(req.body) ; 
        res.send("Success !");
});

app.use(function(req,res){
    res.statusCode = 404;
    res.sendFile("ErrorPage.html",{root:__dirname});
}); // for other requests !
app.listen(5000,()=>{
    console.log('Server running at port 5000 !')
});