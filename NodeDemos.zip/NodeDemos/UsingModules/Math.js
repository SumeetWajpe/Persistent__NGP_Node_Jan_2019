function Add(x,y) {
        return x + y;
}
function Product(x,y) {
    return x * y;
}
// module.exports.Add = Add;
// module.exports.Product = Product;
// OR
module.exports = {Addition:Add,Multiplication:Product}